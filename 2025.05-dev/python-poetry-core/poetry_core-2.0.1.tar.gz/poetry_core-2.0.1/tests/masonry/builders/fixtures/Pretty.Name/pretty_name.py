"""Example module"""
